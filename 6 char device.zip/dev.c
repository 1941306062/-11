#include <linux/module.h>
#include <linux/types.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/init.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <asm/uaccess.h>

#define DEV_SIZE 102400

struct Device{
char *data;
long size;
}*devp;

struct cdev cdev;
static int devNum_major=255;

static loff_t my_llseek(struct file *file,loff_t offset,int whence)
{
	loff_t cfo=0;
	switch(whence){
	case 0:
	cfo=offset;break;
	case 1:
	cfo=file->f_pos+offset;break;
	case 2:
	cfo=DEV_SIZE-1+offset;break;
	}
	if((cfo<0)||(cfo>DEV_SIZE))
	return -EINVAL;
	file->f_pos=cfo;
	return cfo;
}
static ssize_t my_read(struct file *file,char __user *buf,size_t count,loff_t *p_cfo)
{
	int val=0;
	struct Device *dev = file->private_data;
	if(copy_to_user(buf,(void *)(dev->data+*p_cfo),count))
		val=-EFAULT;
	else
	{
		*p_cfo+=count;
		val=count;
	}
	return val;
}

static ssize_t my_write(struct file *file,const char __user *buf,size_t count,loff_t *p_cfo)
{
	int val=0;
	struct Device *dev = file->private_data;
	if(copy_from_user(dev->data+*p_cfo,buf,count))
		val=-EFAULT;
	else
	{
		*p_cfo+=count;
		val=count;
	}
	return val;
}
static int my_open(struct inode *inode,struct file *file)
{
	file->private_data=devp;
	return 0;
}
struct file_operations fops={
	.owner=THIS_MODULE,
	.llseek=my_llseek,
	.read=my_read,
	.write=my_write,
	.open=my_open,
};
int init_module(void)
{
	int dev_num;
	dev_num=register_chrdev(255,"copy",&fops);
	if(dev_num<0){
	printk(KERN_INFO"copy:FAIL to get major number\n");
	return dev_num;
	}
	if(devNum_major==255)
	devNum_major=dev_num;
	cdev_init(&cdev,&fops);
	cdev.owner=THIS_MODULE;
	cdev.ops=&fops;
	cdev_add(&cdev,MKDEV(devNum_major,255),1);
	devp=kmalloc(sizeof(struct Device),GFP_KERNEL);
	if(!devp)
	{
		dev_num=-ENOMEM;
		printk(KERN_INFO"copy:FAIL to get memmory\n");
	return dev_num;
	}
	(*devp).size=DEV_SIZE;
	(*devp).data=kmalloc(DEV_SIZE,GFP_KERNEL);
	memset((*devp).data,0,(*devp).size);
	return 0;
}
void cleanup_module(void)
{
	cdev_del(&cdev);
	kfree(devp);
	kfree((*devp).data);
	unregister_chrdev(devNum_major,"MyDeiveDriver");
}
MODULE_LICENSE("GPL");
