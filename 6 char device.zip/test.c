#include <stdio.h>
#include <stdlib.h>
#include <linux/fcntl.h>
#define BUFFER_SIZE 102400
int main(void)
{
	int dev,i=0;
	char c;
	char source[BUFFER_SIZE];
	char goal[BUFFER_SIZE];
	printf("请输入一个字符串\n");
	while((c=getchar())!='\n')
	{
		source[i++]=c;
	}
	//printf("\n");
	if((dev=open("/dev/dev",O_RDWR))==-1)
		printf("\t打开设备失败\n");
	else
		printf("\t成功打开设备\n");
	//printf("source:\n%s\n\n",source);
	write(dev,source,sizeof(source));
	lseek(dev,0,SEEK_SET);
	read(dev,goal,sizeof(source));
	printf("结果为:\n%s\n\n",goal);
	return 0;
}
